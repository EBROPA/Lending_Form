import React, { useState } from 'react';
import styles from './pageCSS/DesktopLending.module.css';
import backgroundImg from '../assets/backgroundDesktop.jpg';
import PhoneInput from '../UI/PhoneInput.jsx';

const Modal = ({ isOpen, onClose, message }) => {
  if (!isOpen) return null;

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modalContent} onClick={(e) => e.stopPropagation()}>
        <p className={styles.modalMessage}>{message}</p>
        <button className={styles.modalCloseButton} onClick={onClose}>
          Закрыть
        </button>
      </div>
    </div>
  );
};

export default function DesktopLending() {
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const isPhoneComplete = (phoneNumber) => {
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    return digitsOnly.length === 11;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isPhoneComplete(phone)) {
      setModalMessage('Пожалуйста, введите полный номер телефона');
      setIsModalOpen(true);
      return;
    }

    setStatus('Отправка...');
    setModalMessage('Отправка...');
    setIsModalOpen(true);

    try {
      const res = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });

      if (!res.ok) throw new Error(await res.text());

      setModalMessage('Спасибо! Наш специалист свяжется с вами.');
      setPhone('');
      setStatus('Спасибо! Наш специалист свяжется с вами.');
    } catch (err) {
      console.error(err);
      setModalMessage('Ошибка отправки. Попробуйте ещё раз.');
      setStatus('Ошибка отправки. Попробуйте ещё раз.');
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    if (status === 'Спасибо! Наш специалист свяжется с вами.') {
        setStatus('');
    }
  };

  return (
    <div className={styles.background}>
      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        message={modalMessage}
      />

      <div className={styles.container}>
        <img
          src={backgroundImg}
          alt="Hero background"
          className={styles.photo}
        />
        <div className={styles.textBack}>
          <div className={styles.h1TextContainer}>
            <p className={styles.h1Text}>
              Новостройки премиум <br />и бизнес класса в Москве
            </p>
          </div>
          <form className={styles.callBack} onSubmit={handleSubmit}>
            <PhoneInput
              value={phone}
              onAccept={val => setPhone(val)}
              onComplete={val => {}}
              required
            />
            <button type="submit" className={styles.button}>
              Получить презентацию
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}